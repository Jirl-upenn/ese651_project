"""Drone racing environments.
"""
