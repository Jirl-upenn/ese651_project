"""
Python module serving as a project/extension template.
"""

# Register Gym environments.
from .tasks import *
